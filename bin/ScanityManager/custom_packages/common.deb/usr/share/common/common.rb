#!/usr/bin/ruby

# require zone
require 'uri'
require 'net/http'
require 'json'
require 'resolv'

class Common

	def initialize(argv)

		if argv.empty?
			puts "[ ERROR ] - target argument is required."
			exit
		end

		# get the target first ARG
		@target = argv[0]

		# resolv domain to ip
		begin
			@ip = Resolv.getaddress(@target)
		rescue
			puts "[ ERROR ] - unreachable target."
			exit
		end

		# in case of www subdomain
		if @target[0..3] == "www."
			@target = @target[4..@target.length] # remove www subdomain
		end

	end


	def exec_whois
		puts "---------- Whois ---------- \n"
		system("whois -H #{@target}")
	end


	def exec_ipreverse
		puts "---------- Reverse IP lookup ----------\n\n"

		# Send req 
		begin
			uri = URI('http://domains.yougetsignal.com/domains.php')
			res = Net::HTTP.post_form(uri, 'remoteAddress' => @target, 'key' => '1')


			# Get res
			@result = JSON.parse(res.body)



			#Check all domains
			if @result["status"] != "Fail"

				if @result["domainCount"].to_i > 0
		 
					puts "#{@result["domainCount"]} domain(s) found : \n" 

					for domain in @result["domainArray"]
						puts "--- #{domain[0]} ---"
						system "nc -z -v #{domain[0]} 80 2>&1 | egrep  '(\(http\))|(failed:)'"
						puts "\n"
					end
	
				else
					puts "no domain found. \n" 
				end

			else
				puts "[ ERROR ] - Reverse IP service seems not avaiable."
			end

		rescue
			puts "[ ERROR ] - Reverse IP service seems not avaiable."
		end
	end
end

# entry point - start a new common instance
common = Common.new(ARGV)
common.exec_whois
common.exec_ipreverse
